import re

from bs4 import BeautifulSoup

from textanalysis_tool.readers.base_reader import BaseReader


class HTMLReader(BaseReader):
    URL_PATTERN = "^https://www.gutenberg.org/files/([0-9]+)/.*"

    def read(self, filepath: str) -> BeautifulSoup:
        with open(filepath, encoding="utf-8") as file_obj:
            soup = BeautifulSoup(file_obj, features="html.parser")

        if not soup:
            raise ValueError("The file could not be parsed as HTML.")

        return soup

    def get_content(self, filepath: str) -> str:
        soup = self.read(filepath)

        # Find the first h1 tag (The book title)
        title_h1 = soup.find("h1")
        if title_h1 is None:
            raise ValueError(f"No <h1> tag found in the HTML document: {filepath}")

        # Collect all the content after the first h1
        content = []
        for element in title_h1.find_next_siblings():
            text = element.get_text(strip=True)

            # Stop early if we hit this text, which indicate the end of the book
            if "END OF THE PROJECT GUTENBERG EBOOK" in text:
                break

            if text:
                content.append(text)

        return "\n\n".join(content)

    def get_metadata(self, filename) -> dict:
        soup = self.read(filename)

        title_element = soup.select_one('meta[name="dc.title"]')
        title = title_element.get("content") if title_element else "Unknown Title"

        author_element = soup.select_one('meta[name="dc.creator"]')
        author = author_element.get("content") if author_element else "Unknown Author"

        url_element = soup.select_one('meta[name="dcterms.source"]')
        url = str(url_element.get("content")) if url_element else "Unknown URL"

        extracted_id = re.search(self.URL_PATTERN, url, re.DOTALL)
        id = int(extracted_id.group(1)) if extracted_id else None
        return {"title": title, "author": author, "id": id}
