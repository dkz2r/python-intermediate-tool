def main():
    print("Hello from textanalysis-tool!")


if __name__ == "__main__":
    main()
